## Known Gardisto Bugs

### Server

#### Faulty Checks

The RAM and DISK checks erroneously report failures when they are OK

#### Notification email log

new notification overwrites log, does not maintain old logs.

#### Snooze does not work

no matter what the snooze setting is, the alerts still happen

this is output from notify.checkForSnooze
```
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
<sqlite3.Cursor object at 0x7f26e7cab1f0>
```

#### statistics

all satellite stats stored on ind. hosts, and if a host goes down there is no access to these stats to help diagnose. This should be stored on the server and available.

### Satellite
