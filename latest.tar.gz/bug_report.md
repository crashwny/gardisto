## Known Gardisto Bugs

### Server

#### Faulty Checks

The RAM and DISK checks erroneously report failures when they are OK

#### Notification emails

there is no space between "for" and the check name.

#### statistics

all satellite stats stored on ind. hosts, and if a host goes down there is no access to these stats to help diagnose. This should be stored on the server and available.

### Satellite
